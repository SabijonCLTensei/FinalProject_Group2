/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import models.BibleVerse;
import models.BibleVerseManager;
import uis.BibleVerseForm;
/**
 *
 * @author HP
 */
public class BibleVerseController {
    private final BibleVerseManager model;
    private BibleVerseForm view;

    public BibleVerseController(BibleVerseManager model) {
        this.model = model;
    }

    public void setView(BibleVerseForm view) {
        this.view = view;
    }

    public void handleAddBibleVerse(String description, String BibleVerse) {
        //1. Handles validation
        if (description.trim().isEmpty() || BibleVerse.trim().isEmpty()) {
            return;
        }
        //2. Create a new task object
        BibleVerse task = new BibleVerse();
        task.setDescription(description);
        task.setBibleVerse(BibleVerse);
        //3. Controller adds new task object
        this.model.addBibleVerse(task);
        //4. Save the changes to file for data persistence
        this.model.saveBibleVerses();
        //5. Update the view to reflect changes
        if (this.view != null) {
            this.view.refreshBibleVerseList();
        }
    }

    public boolean handleDeleteBibleVerse(String id) {
        //1. Delete the data based on the given string id
        BibleVerse task = this.model.deleteBibleVerse(id);
        if (task != null) {
            this.model.saveBibleVerses(); //persist change
            //2. This id for logging
            System.out.println("Deleted BibleVerse: " + task.getDescription());
            //3. Refresh/Update the view
            if (this.view != null) {
                this.view.refreshBibleVerseList();
            }
            return true;
        } else {
            System.out.println("BibleVerse not found");
            return false;
        }
    }

    public boolean handleUpdateBibleVerse(String id, String description, String BibleVerse, String status) {
        //1. Check if some fields are empty
        if (description.trim().isEmpty() || BibleVerse.trim().isEmpty()
                || status.trim().isEmpty()) {
            return false;
        }
        //2. Find the task to be updated from the list from the list
        BibleVerse task = this.model.findBibleVerse(id);
        //3. Return if task is null
        if (task == null) {
            return false;
        }
        //4. Update task
        task.setDescription(description);
        task.setBibleVerse(BibleVerse);
        task.setStatus(status);
        //5. Save changes to file
        this.model.saveBibleVerses();
        //6. Update the view  
        if (this.view != null) {
            this.view.refreshBibleVerseList();
        }
        return true;
    }

    public List<BibleVerse> getAllBibleVerse() {
        //1. Get the raw HashMap from model
        Collection<BibleVerse> tasksFromMap = this.model.findAll().values();
        //2. Convert the collection to List for easy handling in JList/JTable
        ArrayList<BibleVerse> taskList = new ArrayList<>(tasksFromMap);
        return taskList;
    }

    /**
     * Retrieves a specific BibleVerse object from the Model to display its details in
     * the View.
     *
     * @param id The unique id of a BibleVerse
     * @return The BibleVerse object if found, null otherwise
     */
    public BibleVerse getBibleVerseDetails(String id) {
        return this.model.findBibleVerse(id);
    }
}
