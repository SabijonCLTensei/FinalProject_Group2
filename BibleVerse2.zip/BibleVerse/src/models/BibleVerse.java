/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.io.Serializable;
import java.time.LocalDate;
/**
 *
 * @author HP
 */
public class BibleVerse implements Serializable {
    private String bibleVerseId;
    private String description;
    private String bibleVerse;
    private String dateCreated;
    private String status;    
    private static final long serialVersionUID = 1L; //for compatibility
    
    public BibleVerse() {        
        this.status = "Already read"; //set default to pending
        setDateCreated();
    }

    public String getBibleVerseId() {
        return bibleVerseId;
    }

    public void setBibleVerseId(String bibleVerseId) {
        this.bibleVerseId = bibleVerseId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBibleVerse() {
        return bibleVerse;
    }

    public void setBibleVerse(String bibleVerse) {
        this.bibleVerse = bibleVerse;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    private void setDateCreated() {
        LocalDate now = LocalDate.now();
        this.dateCreated = now.toString();
    }    

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "BibleVerse{" + "bibleVerseId=" + bibleVerseId + ", description=" + description + ", bibleVerse=" + bibleVerse + ", dateCreated=" + dateCreated + ", status=" + status + '}';
    }

    
}
