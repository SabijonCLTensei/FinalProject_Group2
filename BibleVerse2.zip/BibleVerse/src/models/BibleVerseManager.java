/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import utils.IdGenerator;
import java.util.logging.Logger;
import java.util.logging.Level;
/**
 *
 * @author HP
 */
public class BibleVerseManager {
    private HashMap<String, BibleVerse> tasks; //list of tasks
    private final String FILE_PATH = "bibleVerselist.ser";

    public BibleVerseManager() {
        tasks = new HashMap();
    }

    /**
     * addBibleVerse(BibleVerse task)     *
     * @param task Adds new task to the list
     * 
     */
    public void addBibleVerse(BibleVerse task) {
        //get the year part of task created date
        String s = task.getDateCreated().substring(0, 4);
        //generate random number
        String id = IdGenerator.generateId(Integer.parseInt(s));
        //regenerate id if id is already on the list
        if (tasks != null) {
            while (tasks.containsKey(id)) {
                id = IdGenerator.generateId(Integer.parseInt(s));
            }
        }
        task.setBibleVerseId(id);
        //add task to list
        tasks.put(id, task);
    }

    /**
     * deleteBibleVerse(String id)
     *
     * @param id
     * @return task Remove a task from the list
     */
    public BibleVerse deleteBibleVerse(String id) {
        //delete if task is on the list
        return tasks.remove(id);
    }

    /**
     * findBibleVerse(String id)
     *
     * @param id
     * @return BibleVerse Find a task from the list based on ID
     */
    public BibleVerse findBibleVerse(String id) {
        return tasks.get(id);
    }

    /**
     * findAll()     *
     * @return HashMap<String, BibleVerse>
     * Return the list of tasks
     */
    public HashMap<String, BibleVerse> findAll() {
        return tasks;
    }

    /**
     * setBibleVerse()
     * @param task
     * Update the task if some of its details are changed
     */
    public void setBibleVerse(BibleVerse task){
        //get the task id
        tasks.replace(task.getBibleVerseId(), task);
    }
    
    /**
     * loadBibleVerses()
     * Get the list of tasks from the file
     */
    public void loadBibleVerses() {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(FILE_PATH);
            try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                Object readObj = ois.readObject();
                this.tasks = (HashMap<String, BibleVerse>) readObj;
            }
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            Logger.getLogger(BibleVerseManager.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    /**
     * saveBibleVerses()
     * @return int
     * Save the list of tasks to file. If returns 0-success; 1-error.
     */
    public int saveBibleVerses() {
        FileOutputStream fos = null;
        int errorCode = 0; //0-success; 1-error
        try {
            fos = new FileOutputStream(this.FILE_PATH);
            //create object output stream                    
            try ( ObjectOutputStream oos = new ObjectOutputStream(fos)) {
                //write the objects to file
                oos.writeObject(tasks);
            }
            fos.close();
        } catch (IOException e) {
            errorCode = 1;
            Logger.getLogger(BibleVerseManager.class.getName()).log(Level.SEVERE, null, e);
        }
        return errorCode;
    }
}
