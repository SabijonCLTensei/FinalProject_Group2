/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uis;

import controllers.BibleVerseController;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import models.BibleVerse;
//import .ui.Home;


/**
 *
 * @author HP
 */
public class BibleVerseForm extends javax.swing.JFrame {

    
    /**
     * Creates new form BibleVerseForm
     */
    public BibleVerseForm(BibleVerseController controller) {
        this.controller = controller;
        this.tableModel = new BibleVerseTableModel();
                
        initComponents();
        setUpDefaultDisplay();
        
        setupListTable();
        setUpRowSelectionListener();        
        
        refreshBibleVerseList();
        
    }
    
    private void setUpDefaultDisplay(){
        //default labels and textfield visibility
        this.jLabelStatus.setVisible(false);
        this.jLabelCreated.setVisible(false);
        this.jTextFieldStatus.setVisible(false);
        this.jTextFieldCreated.setVisible(false);
        //default textfield text
        this.jTextFieldStatus.setText("");
        this.jTextFieldCreated.setText("");
        this.jTextAreaDesc.setText("");
        this.jTextFieldVerse.setText("");
        
        //default buttons
        this.jButtonDelete.setEnabled(false);
        //default action for save is add
        this.saveMode = "ADD";
    }
    
    private void setupListTable() {
        //set the modified tablemodel
        jTableBibleVerses.setModel(tableModel);
        //This forces the JTable to use the names from taskTableModel.getColumnName(int)
        jTableBibleVerses.getTableHeader().setReorderingAllowed(false);
        // IMPORTANT: Tell the JTable to use the model's column names
        jTableBibleVerses.setAutoCreateColumnsFromModel(true);
        //need this line if the column count changed:
        jTableBibleVerses.createDefaultColumnsFromModel();
        setupTableColumnWidths();
    }
    
    public void refreshBibleVerseList(){
        String savedSelectedId = this.selectedBibleVerseId; //selectedBibleVerseId is the props
        System.out.println("Selected BibleVerse id:" + savedSelectedId);
                
        List<BibleVerse> tasks = controller.getAllBibleVerse();
        for (BibleVerse task : tasks) {
            System.out.println(task);
        }
        //2. Update the JTableModel to 
        this.tableModel.setBibleVerses(tasks);
        
        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getBibleVerseId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTableBibleVerses.convertRowIndexToView(newModelRow);
                jTableBibleVerses.setRowSelectionInterval(newTableRow, newTableRow);                
            } else {
                this.selectedBibleVerseId = null;
                setUpDefaultDisplay();
            }
        }
    }
    
    private void setupTableColumnWidths(){
        // Ensure the TableModel is set before calling this method!
        javax.swing.table.TableColumnModel columnModel = jTableBibleVerses.getColumnModel();

        // Column 0: ID (Short, hidden or very narrow)
        columnModel.getColumn(0).setPreferredWidth(75);
        // Optional: Make the ID column hidden or very small
        columnModel.getColumn(0).setMaxWidth(75);
        columnModel.getColumn(0).setMinWidth(75);

        // Column 1: BibleVerse Description (The main content, should be wide)
        columnModel.getColumn(1).setPreferredWidth(100);
        
        // Column 2: Done (DeadLine, should be narrow)
        columnModel.getColumn(2).setPreferredWidth(75);
        columnModel.getColumn(2).setMaxWidth(75); 
        columnModel.getColumn(2).setMinWidth(75);
        
        // Column 3: Done (DeadLine, should be narrow)
        columnModel.getColumn(3).setPreferredWidth(100);
        columnModel.getColumn(3).setMaxWidth(100); 
        columnModel.getColumn(3).setMinWidth(100);
    
        // Column 3: Done (Status, should be narrow)
        columnModel.getColumn(4).setPreferredWidth(65);
        columnModel.getColumn(4).setMaxWidth(65); 
        columnModel.getColumn(4).setMinWidth(65);
    
        // Optional: Disable auto-resize to give full control to preferred widths
        jTableBibleVerses.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
        // The default AUTO_RESIZE_SUBSEQUENT_COLUMNS might also work, but AUTO_RESIZE_LAST_COLUMN 
        // is often best when you've manually set all other column sizes.
    }
    
    private void setUpRowSelectionListener(){
        jTableBibleVerses.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = jTableBibleVerses.getSelectedRow();
                //if row is selected
                if (selectedRow != -1) {
                    int modelRow = jTableBibleVerses.convertRowIndexToModel(selectedRow);
                    String taskId = this.tableModel.getBibleVerseId(modelRow);
                    BibleVerse selectedBibleVerse = controller.getBibleVerseDetails(taskId);
                    displaySelectedBibleVerse(selectedBibleVerse);
                }
            } else {
                setUpDefaultDisplay();
            }
        });        
    }
    
    private void displaySelectedBibleVerse(BibleVerse task){
        this.jTextAreaDesc.setText(task.getDescription());
        this.jTextFieldVerse.setText(task.getBibleVerse());
        this.selectedBibleVerseId = task.getBibleVerseId();
        this.jTextFieldStatus.setText(task.getStatus());
        this.jTextFieldCreated.setText(task.getDateCreated());
        
        //make some fields visible for editing
        this.jLabelStatus.setVisible(true);
        this.jLabelCreated.setVisible(true);
        this.jTextFieldCreated.setVisible(true);
        this.jTextFieldStatus.setVisible(true);
        
        //enables the delete button
        this.jButtonDelete.setEnabled(true);
        //change save button to update
        this.saveMode = "UPDATE";
        System.out.println("SaveMode:" + saveMode);
    }
    
    private void addBibleVerse(){
        //check fields
        String desc = this.jTextAreaDesc.getText();
        String deadline = this.jTextFieldVerse.getText();
        String status = this.jTextFieldStatus.getText();
        boolean success = false;
        //show error message if fields are empty
        //saveMode = "ADD"
        if (this.saveMode.equalsIgnoreCase("ADD")) {
            if (desc.trim().isEmpty() || deadline.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "All Fields are required", "Add BibleVerse", 0);
                return;
            }
            //call the controller handler
            controller.handleAddBibleVerse(desc, deadline);
            success = true;
            JOptionPane.showMessageDialog(this, "BibleVerse Successfully added", "Add BibleVerse", 1);
        } else if(this.saveMode.equalsIgnoreCase("UPDATE")){
            boolean res = controller.handleUpdateBibleVerse(this.selectedBibleVerseId, desc, deadline, status);
            if (res) {
                JOptionPane.showMessageDialog(this, "BibleVerse Successfully Updated", "Update BibleVerse", 1);
                success = true;
            } else {
                JOptionPane.showMessageDialog(this, "An error occured while updating BibleVerse", "Update BibleVerse", 0);
            }
        }     
        
       //clear fields and return display to default if success
        if (success) {
            this.jTableBibleVerses.clearSelection();
            setUpDefaultDisplay();
            this.selectedBibleVerseId = null;
        }       
    }
    
    private void deleteBibleVerse(){
        if (this.selectedBibleVerseId != null) {
            int confirmDeletion = JOptionPane.showConfirmDialog(
                    this, 
                    "Are you sure you want to delete this BibleVerse? This cannot be undone.",
                    "Confirm BibleVerse Deletion", 
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
            //if response is yes
            if (confirmDeletion == JOptionPane.YES_OPTION) {
                boolean success = controller.handleDeleteBibleVerse(this.selectedBibleVerseId);
                if (success) {
                    JOptionPane.showMessageDialog(this, "BibleVerse Successfully Deleted", "BibleVerse Deletion", 1);
                    //clear the display
                    this.jTableBibleVerses.clearSelection();
                } else { //error message if deletion failed
                    JOptionPane.showMessageDialog(this, "An error occured while deleting the BibleVerse", "BibleVerse Deletion", 0);
                }
            } else {
                //do nothing
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableBibleVerses = new javax.swing.JTable();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jLabelDesc = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextAreaDesc = new javax.swing.JTextArea();
        jLabelVerse = new javax.swing.JLabel();
        jTextFieldVerse = new javax.swing.JTextField();
        jLabelCreated = new javax.swing.JLabel();
        jTextFieldCreated = new javax.swing.JTextField();
        jLabelStatus = new javax.swing.JLabel();
        jTextFieldStatus = new javax.swing.JTextField();
        jButtonRefresh = new javax.swing.JButton();
        jButtonSave = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jRadioButtonMenuItemGoBack = new javax.swing.JRadioButtonMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "FAVORITE BIBLE VERSES", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Georgia", 1, 24), new java.awt.Color(255, 255, 255))); // NOI18N

        jTableBibleVerses.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jTableBibleVerses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTableBibleVerses.setOpaque(false);
        jTableBibleVerses.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jTableBibleVerses.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTableBibleVerses);

        jLabelDesc.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelDesc.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDesc.setText("BIBLE VERSE DESCRIPTION");

        jTextAreaDesc.setColumns(20);
        jTextAreaDesc.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jTextAreaDesc.setLineWrap(true);
        jTextAreaDesc.setRows(5);
        jTextAreaDesc.setOpaque(false);
        jScrollPane2.setViewportView(jTextAreaDesc);

        jLabelVerse.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelVerse.setForeground(new java.awt.Color(255, 255, 255));
        jLabelVerse.setText("BIBLE VERSE");

        jTextFieldVerse.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        jTextFieldVerse.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldVerse.setOpaque(false);
        jTextFieldVerse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldVerseActionPerformed(evt);
            }
        });

        jLabelCreated.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelCreated.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCreated.setText("DATE CREATED");

        jTextFieldCreated.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        jTextFieldCreated.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldCreated.setOpaque(false);

        jLabelStatus.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelStatus.setForeground(new java.awt.Color(255, 255, 255));
        jLabelStatus.setText("STATUS");

        jTextFieldStatus.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        jTextFieldStatus.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldStatus.setOpaque(false);
        jTextFieldStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldStatusActionPerformed(evt);
            }
        });

        jButtonRefresh.setBackground(new java.awt.Color(204, 255, 255));
        jButtonRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonRefresh.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRefresh.setText("REFRESH");
        jButtonRefresh.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 255, 255), 5, true));
        jButtonRefresh.setContentAreaFilled(false);
        jButtonRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jLayeredPane2Layout = new javax.swing.GroupLayout(jLayeredPane2);
        jLayeredPane2.setLayout(jLayeredPane2Layout);
        jLayeredPane2Layout.setHorizontalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
                    .addComponent(jTextFieldVerse)
                    .addComponent(jTextFieldCreated)
                    .addComponent(jTextFieldStatus)
                    .addGroup(jLayeredPane2Layout.createSequentialGroup()
                        .addGroup(jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDesc)
                            .addComponent(jLabelVerse)
                            .addComponent(jLabelCreated)
                            .addComponent(jLabelStatus)
                            .addComponent(jButtonRefresh))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jLayeredPane2Layout.setVerticalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelDesc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelVerse)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldVerse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelCreated)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldCreated, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelStatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextFieldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonRefresh)
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jLayeredPane2.setLayer(jLabelDesc, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jLabelVerse, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jTextFieldVerse, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jLabelCreated, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jTextFieldCreated, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jLabelStatus, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jTextFieldStatus, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane2.setLayer(jButtonRefresh, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jButtonSave.setBackground(new java.awt.Color(0, 51, 0));
        jButtonSave.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButtonSave.setForeground(new java.awt.Color(255, 255, 255));
        jButtonSave.setText("SAVE VERSE");
        jButtonSave.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 51, 0), 10, true));
        jButtonSave.setContentAreaFilled(false);
        jButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveActionPerformed(evt);
            }
        });

        jButtonDelete.setBackground(new java.awt.Color(102, 0, 0));
        jButtonDelete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButtonDelete.setForeground(new java.awt.Color(255, 255, 255));
        jButtonDelete.setText("DELETE VERSE");
        jButtonDelete.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 0, 0), 10, true));
        jButtonDelete.setContentAreaFilled(false);
        jButtonDelete.setPreferredSize(new java.awt.Dimension(143, 31));
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLayeredPane2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                            .addComponent(jButtonSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(38, 38, 38))))
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addComponent(jLayeredPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonSave, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 55, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jLayeredPane1.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLayeredPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButtonSave, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButtonDelete, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 800, 590));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uis/biblesss.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jMenu4.setText("Home");

        jRadioButtonMenuItemGoBack.setSelected(true);
        jRadioButtonMenuItemGoBack.setText("Go Back");
        jRadioButtonMenuItemGoBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemGoBackActionPerformed(evt);
            }
        });
        jMenu4.add(jRadioButtonMenuItemGoBack);

        jMenuBar1.add(jMenu4);

        jMenu1.setText("File");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");
        jRadioButtonMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jRadioButtonMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldVerseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldVerseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldVerseActionPerformed

    private void jTextFieldStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldStatusActionPerformed

    private void jButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveActionPerformed
        System.out.println("Button Clicked");
        addBibleVerse();
    }//GEN-LAST:event_jButtonSaveActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
        System.out.println("Delete is clicked!");
        deleteBibleVerse();
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    private void jButtonRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRefreshActionPerformed
        setUpDefaultDisplay();
    }//GEN-LAST:event_jButtonRefreshActionPerformed

    private void jRadioButtonMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonMenuItem1ActionPerformed

    private void jRadioButtonMenuItemGoBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemGoBackActionPerformed
        openHome();
    }//GEN-LAST:event_jRadioButtonMenuItemGoBackActionPerformed

    public void openHome(){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new Home().setVisible(true);
            }
        });
        dispose();
    }
    
//    public void openHome(){
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Home().setVisible(true);
//            }
//        });
//        dispose();
//    }
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(BibleVerseForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(BibleVerseForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(BibleVerseForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(BibleVerseForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new BibleVerseForm().setVisible(true);
//            }
//        });
//    }

    private BibleVerseController controller;
    private BibleVerseTableModel tableModel;
    private String selectedBibleVerseId;
    private String saveMode;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonRefresh;
    private javax.swing.JButton jButtonSave;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelCreated;
    private javax.swing.JLabel jLabelDesc;
    private javax.swing.JLabel jLabelStatus;
    private javax.swing.JLabel jLabelVerse;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemGoBack;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableBibleVerses;
    private javax.swing.JTextArea jTextAreaDesc;
    private javax.swing.JTextField jTextFieldCreated;
    private javax.swing.JTextField jTextFieldStatus;
    private javax.swing.JTextField jTextFieldVerse;
    // End of variables declaration//GEN-END:variables
}
