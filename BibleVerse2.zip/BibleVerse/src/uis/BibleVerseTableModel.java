/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uis;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import models.BibleVerse;
/**
 *
 * @author HP
 */
public class BibleVerseTableModel extends AbstractTableModel {
    private List<BibleVerse> tasks;
    private final String[] COLUMN_NAMES = {"Verse ID","Description",
        "Date Created", "Verse", "Status"};

    public BibleVerseTableModel(){
        this.tasks = new ArrayList<>();
    }    
    @Override
    public int getRowCount() {
        return this.tasks.size();
    }
    @Override
    public int getColumnCount() {
        return this.COLUMN_NAMES.length;
    }        
    @Override
    public String getColumnName(int index) {
        return COLUMN_NAMES[index]; 
    }    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        BibleVerse task = tasks.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return task.getBibleVerseId();
            case 1:
                return task.getDescription();
            case 2:
                return task.getDateCreated();
            case 3:
                return task.getBibleVerse();
            case 4:
                return task.getStatus();
            default:
                return null;
        }        
    }
    
    public void setBibleVerses(List<BibleVerse> tasks){
        this.tasks = tasks;
        fireTableDataChanged();
    }
    
    public String getBibleVerseId(int rowIndex){
        return tasks.get(rowIndex).getBibleVerseId();
    }
    
}
