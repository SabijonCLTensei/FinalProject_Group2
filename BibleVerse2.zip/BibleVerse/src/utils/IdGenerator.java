/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.util.Random;

/**
 *
 * @author HP
 */
public class IdGenerator {
    public static String generateId(int year){
        Random random = new Random();
        int r = random.nextInt(1000000); //random number from 0 to 999999
        //convert the random number to a six digit string        
        return String.format("%d-%06d", year, r); //year=2024 r=231 -> 2024-000231
    }
}
