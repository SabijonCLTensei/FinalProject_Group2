/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import model.BusTerminal;
import model.BusTerminalManager;
import ui.BusTerminalForm;
/**
 *
 * @author HP
 */
public class BusTerminalController {
    private final BusTerminalManager model;
    private BusTerminalForm view;

    public BusTerminalController(BusTerminalManager model) {
        this.model = model;
    }

    public void setView(BusTerminalForm view) {
        this.view = view;
    }

    public void handleAddBusTerminal(String bus, String depart) {
        //1. Handles validation
        if (bus.trim().isEmpty() || depart.trim().isEmpty()) {
            return;
        }
        //2. Create a new task object
        BusTerminal task = new BusTerminal();
        task.setBus(bus);
        task.setDepart(depart);
        //3. Controller adds new task object
        this.model.addBusTerminal(task);
        //4. Save the changes to file for data persistence
        this.model.saveBusTerminals();
        //5. Update the view to reflect changes
        if (this.view != null) {
            this.view.refreshBusTerminalList();
        }
    }

    public boolean handleDeleteBusTerminal(String id) {
        //1. Delete the data based on the given string id
        BusTerminal task = this.model.deleteBusTerminal(id);
        if (task != null) {
            this.model.saveBusTerminals(); //persist change
            //2. This id for logging
            System.out.println("Deleted BusTerminal: " + task.getBus());
            //3. Refresh/Update the view
            if (this.view != null) {
                this.view.refreshBusTerminalList();
            }
            return true;
        } else {
            System.out.println("BusTerminal not found");
            return false;
        }
    }

    public boolean handleUpdateBusTerminal(String id, String bus, String depart, String status) {
        //1. Check if some fields are empty
        if (bus.trim().isEmpty() || depart.trim().isEmpty()
                || status.trim().isEmpty()) {
            return false;
        }
        //2. Find the task to be updated from the list from the list
        BusTerminal task = this.model.findBusTerminal(id);
        //3. Return if task is null
        if (task == null) {
            return false;
        }
        //4. Update task
        task.setBus(bus);
        task.setDepart(depart);
        task.setStatus(status);
        //5. Save changes to file
        this.model.saveBusTerminals();
        //6. Update the view  
        if (this.view != null) {
            this.view.refreshBusTerminalList();
        }
        return true;
    }

    public List<BusTerminal> getAllBusTerminal() {
        //1. Get the raw HashMap from model
        Collection<BusTerminal> tasksFromMap = this.model.findAll().values();
        //2. Convert the collection to List for easy handling in JList/JTable
        ArrayList<BusTerminal> taskList = new ArrayList<>(tasksFromMap);
        return taskList;
    }

    /**
     * Retrieves a specific BusTerminal object from the Model to display its details in
     * the View.
     *
     * @param id The unique id of a BusTerminal
     * @return The BusTerminal object if found, null otherwise
     */
    public BusTerminal getBusTerminalDetails(String id) {
        return this.model.findBusTerminal(id);
    }
}
