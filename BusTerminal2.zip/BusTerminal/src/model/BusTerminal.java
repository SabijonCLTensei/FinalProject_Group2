/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author HP
 */
public class BusTerminal implements Serializable {
    private String busTerminalId;
    private String bus;
    private String depart;
    private String dateCreated;
    private String status;    
    private static final long serialVersionUID = 1L; //for compatibility
    
    public BusTerminal() {        
        this.status = "Waiting"; //set default to pending
        setDateCreated();
    }

    public String getBusTerminalId() {
        return busTerminalId;
    }

    public void setBusTerminalId(String busTerminalId) {
        this.busTerminalId = busTerminalId;
    }

    public String getBus() {
        return bus;
    }

    public void setBus(String bus) {
        this.bus = bus;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    private void setDateCreated() {
        LocalDate now = LocalDate.now();
        this.dateCreated = now.toString();
    }    

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "BusTerminal{" + "busTerminalId=" + busTerminalId + ", bus=" + bus + ", depart=" + depart + ", dateCreated=" + dateCreated + ", status=" + status + '}';
    }
}

