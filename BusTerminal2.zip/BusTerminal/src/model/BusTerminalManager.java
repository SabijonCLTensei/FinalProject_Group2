/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import util.IdGenerator;
import java.util.logging.Logger;
import java.util.logging.Level;
/**
 *
 * @author HP
 */
public class BusTerminalManager {
    private HashMap<String, BusTerminal> busTerminals; //list of busTerminals
    private final String FILE_PATH = "busTerminalslist.ser";

    public BusTerminalManager() {
        busTerminals = new HashMap();
    }

    /**
     * addBusTerminal(BusTerminal busTerminal)     *
     * @param busTerminal Adds new busTerminal to the list
     * 
     */
    public void addBusTerminal(BusTerminal busTerminal) {
        //get the year part of busTerminal created date
        String s = busTerminal.getDateCreated().substring(0, 4);
        //generate random number
        String id = IdGenerator.generateId(Integer.parseInt(s));
        //regenerate id if id is already on the list
        if (busTerminals != null) {
            while (busTerminals.containsKey(id)) {
                id = IdGenerator.generateId(Integer.parseInt(s));
            }
        }
        busTerminal.setBusTerminalId(id);
        //add busTerminal to list
        busTerminals.put(id, busTerminal);
    }

    /**
     * deleteBusTerminal(String id)
     *
     * @param id
     * @return busTerminal Remove a busTerminal from the list
     */
    public BusTerminal deleteBusTerminal(String id) {
        //delete if busTerminal is on the list
        return busTerminals.remove(id);
    }

    /**
     * findBusTerminal(String id)
     *
     * @param id
     * @return BusTerminal Find a busTerminal from the list based on ID
     */
    public BusTerminal findBusTerminal(String id) {
        return busTerminals.get(id);
    }

    /**
     * findAll()     *
     * @return HashMap<String, BusTerminal>
     * Return the list of busTerminals
     */
    public HashMap<String, BusTerminal> findAll() {
        return busTerminals;
    }

    /**
     * setBusTerminal()
     * @param busTerminal
     * Update the busTerminal if some of its details are changed
     */
    public void setBusTerminal(BusTerminal busTerminal){
        //get the busTerminal id
        busTerminals.replace(busTerminal.getBusTerminalId(), busTerminal);
    }
    
    /**
     * loadBusTerminals()
     * Get the list of busTerminals from the file
     */
    public void loadBusTerminals() {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(FILE_PATH);
            try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                Object readObj = ois.readObject();
                this.busTerminals = (HashMap<String, BusTerminal>) readObj;
            }
            fis.close();
        } catch (IOException | ClassNotFoundException e) {
            Logger.getLogger(BusTerminalManager.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    /**
     * saveBusTerminals()
     * @return int
     * Save the list of busTerminals to file. If returns 0-success; 1-error.
     */
    public int saveBusTerminals() {
        FileOutputStream fos = null;
        int errorCode = 0; //0-success; 1-error
        try {
            fos = new FileOutputStream(this.FILE_PATH);
            //create object output stream                    
            try ( ObjectOutputStream oos = new ObjectOutputStream(fos)) {
                //write the objects to file
                oos.writeObject(busTerminals);
            }
            fos.close();
        } catch (IOException e) {
            errorCode = 1;
            Logger.getLogger(BusTerminalManager.class.getName()).log(Level.SEVERE, null, e);
        }
        return errorCode;
    }
}
