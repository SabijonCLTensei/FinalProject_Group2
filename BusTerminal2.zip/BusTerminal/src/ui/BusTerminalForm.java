/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import controller.BusTerminalController;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import model.BusTerminal;
/**
 *
 * @author HP
 */
public class BusTerminalForm extends javax.swing.JFrame {

    /**
     * Creates new form BusTerminalForm
     */
    public BusTerminalForm(BusTerminalController controller) {
        this.controller = controller;
        this.tableModel = new BusTerminalTableModel();
                
        initComponents();
        setUpDefaultDisplay();
        
        setupListTable();
        setUpRowSelectionListener();        
        
        refreshBusTerminalList();
    }

    private void setUpDefaultDisplay(){
        //default labels and textfield visibility
        this.jLabelStatus.setVisible(false);
        this.jLabelCreated.setVisible(false);
        this.jTextFieldStatus.setVisible(false);
        this.jTextFieldCreated.setVisible(false);
        //default textfield text
        this.jTextFieldStatus.setText("");
        this.jTextFieldCreated.setText("");
        this.jTextFieldDesc.setText("");
        this.jTextFieldDepart.setText("");
        
        //default buttons
        this.jButtonDelete.setEnabled(false);
        //default action for save is add
        this.saveMode = "ADD";
    }
    
    private void setupListTable() {
        //set the modified tablemodel
        jTableBusTerminalEntry.setModel(tableModel);
        //This forces the JTable to use the names from busTerminalTableModel.getColumnName(int)
        jTableBusTerminalEntry.getTableHeader().setReorderingAllowed(false);
        // IMPORTANT: Tell the JTable to use the model's column names
        jTableBusTerminalEntry.setAutoCreateColumnsFromModel(true);
        //need this line if the column count changed:
        jTableBusTerminalEntry.createDefaultColumnsFromModel();
        setupTableColumnWidths();
    }
    
    public void refreshBusTerminalList(){
        String savedSelectedId = this.selectedBusTerminalId; //selectedBusTerminalId is the props
        System.out.println("Selected busTerminal  id:" + savedSelectedId);
                
        List<BusTerminal> busTerminals = controller.getAllBusTerminal();
        for (BusTerminal busTerminal : busTerminals) {
            System.out.println(busTerminal);
        }
        //2. Update the JTableModel to 
        this.tableModel.setBusTerminals(busTerminals);
        
        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getBusTerminalId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTableBusTerminalEntry.convertRowIndexToView(newModelRow);
                jTableBusTerminalEntry.setRowSelectionInterval(newTableRow, newTableRow);                
            } else {
                this.selectedBusTerminalId = null;
                setUpDefaultDisplay();
            }
        }
    }
    
    private void setupTableColumnWidths(){
        // Ensure the TableModel is set before calling this method!
        javax.swing.table.TableColumnModel columnModel = jTableBusTerminalEntry.getColumnModel();

        // Column 0: ID (Short, hidden or very narrow)
        columnModel.getColumn(0).setPreferredWidth(100);
        // Optional: Make the ID column hidden or very small
        columnModel.getColumn(0).setMaxWidth(100);
        columnModel.getColumn(0).setMinWidth(100);

        // Column 1: BusTerminal Bus (The main content, should be wide)
        columnModel.getColumn(1).setPreferredWidth(100);
        
        // Column 2: Done (DeadLine, should be narrow)
        columnModel.getColumn(2).setPreferredWidth(100);
        columnModel.getColumn(2).setMaxWidth(100); 
        columnModel.getColumn(2).setMinWidth(100);
        
        // Column 3: Done (DeadLine, should be narrow)
        columnModel.getColumn(3).setPreferredWidth(100);
        columnModel.getColumn(3).setMaxWidth(100); 
        columnModel.getColumn(3).setMinWidth(100);
    
        // Column 3: Done (Status, should be narrow)
        columnModel.getColumn(4).setPreferredWidth(100);
        columnModel.getColumn(4).setMaxWidth(100); 
        columnModel.getColumn(4).setMinWidth(100);
    
        // Optional: Disable auto-resize to give full control to preferred widths
        jTableBusTerminalEntry.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
        // The default AUTO_RESIZE_SUBSEQUENT_COLUMNS might also work, but AUTO_RESIZE_LAST_COLUMN 
        // is often best when you've manually set all other column sizes.
    }
    
    private void setUpRowSelectionListener(){
        jTableBusTerminalEntry.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = jTableBusTerminalEntry.getSelectedRow();
                //if row is selected
                if (selectedRow != -1) {
                    int modelRow = jTableBusTerminalEntry.convertRowIndexToModel(selectedRow);
                    String busTerminalId = this.tableModel.getBusTerminalId(modelRow);
                    BusTerminal selectedBusTerminal = controller.getBusTerminalDetails(busTerminalId);
                    displaySelectedBusTerminal(selectedBusTerminal);
                }
            } else {
                setUpDefaultDisplay();
            }
        });        
    }
    
    private void displaySelectedBusTerminal(BusTerminal busTerminal){
        this.jTextFieldDesc.setText(busTerminal.getBus());
        this.jTextFieldDepart.setText(busTerminal.getDepart());
        this.selectedBusTerminalId = busTerminal.getBusTerminalId();
        this.jTextFieldStatus.setText(busTerminal.getStatus());
        this.jTextFieldCreated.setText(busTerminal.getDateCreated());
        
        //make some fields visible for editing
        this.jLabelStatus.setVisible(true);
        this.jLabelCreated.setVisible(true);
        this.jTextFieldCreated.setVisible(true);
        this.jTextFieldStatus.setVisible(true);
        
        //enables the delete button
        this.jButtonDelete.setEnabled(true);
        //change save button to update
        this.saveMode = "UPDATE";
        System.out.println("SaveMode:" + saveMode);
    }
    
    private void addBusTerminal(){
        //check fields
        String desc = this.jTextFieldDesc.getText();
        String depart = this.jTextFieldDepart.getText();
        String status = this.jTextFieldStatus.getText();
        boolean success = false;
        //show error message if fields are empty
        //saveMode = "ADD"
        if (this.saveMode.equalsIgnoreCase("ADD")) {
            if (desc.trim().isEmpty() || depart.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "All Fields are required", "Add BusTerminal", 0);
                return;
            }
            //call the controller handler
            controller.handleAddBusTerminal(desc, depart);
            success = true;
            JOptionPane.showMessageDialog(this, "BusTerminal Successfully added", "Add BusTerminal", 1);
        } else if(this.saveMode.equalsIgnoreCase("UPDATE")){
            boolean res = controller.handleUpdateBusTerminal(this.selectedBusTerminalId, desc, depart, status);
            if (res) {
                JOptionPane.showMessageDialog(this, "BusTerminal Successfully Updated", "Update BusTerminal", 1);
                success = true;
            } else {
                JOptionPane.showMessageDialog(this, "An error occured while updating busTerminal", "Update BusTerminal", 0);
            }
        }     
        
       //clear fields and return display to default if success
        if (success) {
            this.jTableBusTerminalEntry.clearSelection();
            setUpDefaultDisplay();
            this.selectedBusTerminalId = null;
        }       
    }
    
    private void deleteBusTerminal(){
        if (this.selectedBusTerminalId != null) {
            int confirmDeletion = JOptionPane.showConfirmDialog(
                    this, 
                    "Are you sure you want to delete this BusTerminal? This cannot be undone.",
                    "Confirm BusTerminal Deletion", 
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
            //if response is yes
            if (confirmDeletion == JOptionPane.YES_OPTION) {
                boolean success = controller.handleDeleteBusTerminal(this.selectedBusTerminalId);
                if (success) {
                    JOptionPane.showMessageDialog(this, "BusTerminal Successfully Deleted", "BusTerminal Deletion", 1);
                    //clear the display
                    this.jTableBusTerminalEntry.clearSelection();
                } else { //error message if deletion failed
                    JOptionPane.showMessageDialog(this, "An error occured while deleting the busTerminal", "BusTerminal Deletion", 0);
                }
            } else {
                //do nothing
            }
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableBusTerminalEntry = new javax.swing.JTable();
        jLabelDesc = new javax.swing.JLabel();
        jLabelDepart = new javax.swing.JLabel();
        jLabelCreated = new javax.swing.JLabel();
        jLabelStatus = new javax.swing.JLabel();
        jTextFieldDesc = new javax.swing.JTextField();
        jTextFieldDepart = new javax.swing.JTextField();
        jTextFieldCreated = new javax.swing.JTextField();
        jTextFieldStatus = new javax.swing.JTextField();
        jButtonDelete = new javax.swing.JButton();
        jButtonSave = new javax.swing.JButton();
        jButtonRefresh = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "BUS TERMINAL DEPARTING ENTRY", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Constantia", 1, 24), new java.awt.Color(255, 255, 255))); // NOI18N

        jLayeredPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "DEPARTING BUS ENTRY", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 14), new java.awt.Color(255, 255, 255))); // NOI18N

        javax.swing.GroupLayout jLayeredPane2Layout = new javax.swing.GroupLayout(jLayeredPane2);
        jLayeredPane2.setLayout(jLayeredPane2Layout);
        jLayeredPane2Layout.setHorizontalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jLayeredPane2Layout.setVerticalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 201, Short.MAX_VALUE)
        );

        jTableBusTerminalEntry.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTableBusTerminalEntry.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTableBusTerminalEntry.setOpaque(false);
        jScrollPane1.setViewportView(jTableBusTerminalEntry);

        jLabelDesc.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabelDesc.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDesc.setText("BUS DESCRIPTION");

        jLabelDepart.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabelDepart.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDepart.setText("DEPARTING IN");

        jLabelCreated.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabelCreated.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCreated.setText("DATE REGISTERED");

        jLabelStatus.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabelStatus.setForeground(new java.awt.Color(255, 255, 255));
        jLabelStatus.setText("STATUS");

        jTextFieldDesc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldDescActionPerformed(evt);
            }
        });

        jButtonDelete.setBackground(new java.awt.Color(51, 0, 0));
        jButtonDelete.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jButtonDelete.setForeground(new java.awt.Color(102, 0, 0));
        jButtonDelete.setText("DELETE ENTRY");
        jButtonDelete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 0, 0), 5));
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        jButtonSave.setBackground(new java.awt.Color(0, 51, 0));
        jButtonSave.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jButtonSave.setForeground(new java.awt.Color(0, 102, 0));
        jButtonSave.setText("SAVE ENTRY");
        jButtonSave.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 0), 5));
        jButtonSave.setPreferredSize(new java.awt.Dimension(119, 27));
        jButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveActionPerformed(evt);
            }
        });

        jButtonRefresh.setBackground(new java.awt.Color(204, 255, 255));
        jButtonRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonRefresh.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRefresh.setText("REFRESH");
        jButtonRefresh.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 255, 255), 5, true));
        jButtonRefresh.setContentAreaFilled(false);
        jButtonRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 756, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLayeredPane2))
                    .addGroup(jLayeredPane1Layout.createSequentialGroup()
                        .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabelDesc)
                                .addComponent(jLabelStatus)
                                .addComponent(jLabelCreated)
                                .addComponent(jLabelDepart)
                                .addComponent(jTextFieldDesc)
                                .addComponent(jTextFieldDepart)
                                .addComponent(jTextFieldCreated)
                                .addComponent(jTextFieldStatus)
                                .addGroup(jLayeredPane1Layout.createSequentialGroup()
                                    .addComponent(jButtonSave, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)))
                            .addComponent(jButtonRefresh))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelDesc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldDesc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelDepart)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldDepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelCreated)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldCreated, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelStatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
                    .addComponent(jButtonSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLayeredPane2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );
        jLayeredPane1.setLayer(jLayeredPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabelDesc, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabelDepart, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabelCreated, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jLabelStatus, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextFieldDesc, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextFieldDepart, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextFieldCreated, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jTextFieldStatus, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButtonDelete, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButtonSave, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jButtonRefresh, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel1.add(jLayeredPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 800, 580));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ui/bus.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldDescActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDescActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldDescActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
        System.out.println("Delete is clicked!");
        deleteBusTerminal();
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    private void jButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveActionPerformed
        System.out.println("Button Clicked");
        addBusTerminal();
    }//GEN-LAST:event_jButtonSaveActionPerformed

    private void jButtonRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRefreshActionPerformed
        setUpDefaultDisplay();
    }//GEN-LAST:event_jButtonRefreshActionPerformed

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(BusTerminalForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(BusTerminalForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(BusTerminalForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(BusTerminalForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new BusTerminalForm().setVisible(true);
//            }
//        });
//    }

    
    private BusTerminalController controller;
    private BusTerminalTableModel tableModel;
    private String selectedBusTerminalId;
    private String saveMode;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonRefresh;
    private javax.swing.JButton jButtonSave;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelCreated;
    private javax.swing.JLabel jLabelDepart;
    private javax.swing.JLabel jLabelDesc;
    private javax.swing.JLabel jLabelStatus;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableBusTerminalEntry;
    private javax.swing.JTextField jTextFieldCreated;
    private javax.swing.JTextField jTextFieldDepart;
    private javax.swing.JTextField jTextFieldDesc;
    private javax.swing.JTextField jTextFieldStatus;
    // End of variables declaration//GEN-END:variables
}
