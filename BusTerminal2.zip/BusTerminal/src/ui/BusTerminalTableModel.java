/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.BusTerminal;
/**
 *
 * @author HP
 */
public class BusTerminalTableModel extends AbstractTableModel {
    private List<BusTerminal> busTerminals;
    private final String[] COLUMN_NAMES = {"BUSTERMINAL ID","BUS",
        "DATE CREATED", "DEPARTING IN", "STATUS"};

    public BusTerminalTableModel(){
        this.busTerminals = new ArrayList<>();
    }    
    @Override
    public int getRowCount() {
        return this.busTerminals.size();
    }
    @Override
    public int getColumnCount() {
        return this.COLUMN_NAMES.length;
    }        
    @Override
    public String getColumnName(int index) {
        return COLUMN_NAMES[index]; 
    }    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        BusTerminal busTerminal = busTerminals.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return busTerminal.getBusTerminalId();
            case 1:
                return busTerminal.getBus();
            case 2:
                return busTerminal.getDateCreated();
            case 3:
                return busTerminal.getDepart();
            case 4:
                return busTerminal.getStatus();
            default:
                return null;
        }        
    }
    
    public void setBusTerminals(List<BusTerminal> busTerminals){
        this.busTerminals = busTerminals;
        fireTableDataChanged();
    }
    
    public String getBusTerminalId(int rowIndex){
        return busTerminals.get(rowIndex).getBusTerminalId();
    }
    
}
