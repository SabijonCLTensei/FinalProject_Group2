/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.util.ArrayList;
import java.util.Comparator;
import controller.AttendanceController;
import java.util.List;
import javax.swing.JOptionPane;
import model.Attendance;

/**
 *
 * @author User
 */
public class Attendances extends javax.swing.JFrame {

    public Attendances(AttendanceController controller) {
        this.controller = controller;
        this.tableModel = new AttendanceTableModel();
        setTitle("Attendance sa mga ADDICT!!!!");
        
        initComponents();

        setUpDefaultDisplay();

        setupListTable();
        setUpRowSelectionListener();

        refreshAttendanceList();
    }

    private void setUpDefaultDisplay() {
        this.jLabel4.setVisible(false);
        this.jLabel5.setVisible(false);
        this.jTextField4status.setVisible(false);
        this.jTextField5date.setVisible(false);

        this.jTextField1names.setText("");
        this.jTextField2login.setText("");
        this.jTextField3logout.setText("");
        this.jTextField4status.setText("");
        this.jTextField5date.setText("");
        this.jButton2delete.setEnabled(false);
        this.saveMode = "ADD";
    }

    private void setupListTable() {
        jTable2listoftasks.setModel(tableModel);
        jTable2listoftasks.getTableHeader().setReorderingAllowed(false);
        jTable2listoftasks.setAutoCreateColumnsFromModel(true);
        jTable2listoftasks.createDefaultColumnsFromModel();
        setupTableColumnWidths();
    }

    public void refreshAttendanceList() {
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }
    }

    private void setupTableColumnWidths() {
        javax.swing.table.TableColumnModel columnModel = jTable2listoftasks.getColumnModel();

        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(0).setMaxWidth(100);
        columnModel.getColumn(0).setMinWidth(100);

        columnModel.getColumn(1).setPreferredWidth(200);

        columnModel.getColumn(2).setPreferredWidth(100);
        columnModel.getColumn(2).setMaxWidth(100);
        columnModel.getColumn(2).setMinWidth(100);

        columnModel.getColumn(3).setPreferredWidth(70);
        columnModel.getColumn(3).setMaxWidth(70);
        columnModel.getColumn(3).setMinWidth(70);

        columnModel.getColumn(4).setPreferredWidth(50);
        columnModel.getColumn(4).setMaxWidth(70);
        columnModel.getColumn(4).setMinWidth(50);

        jTable2listoftasks.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
//        search();
    }

    private void setUpRowSelectionListener() {
        jTable2listoftasks.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = jTable2listoftasks.getSelectedRow();
                if (selectedRow != -1) {
                    int modelRow = jTable2listoftasks.convertRowIndexToModel(selectedRow);
                    String AttendanceId = this.tableModel.getAttendanceId(modelRow);
                    Attendance selectedTask = controller.getTaskDetails(AttendanceId);
                    displaySelectedTask(selectedTask);
                }
            } else {
                setUpDefaultDisplay();
            }
        });
    }

    private void displaySelectedTask(Attendance Attendance) {
        this.jTextField1names.setText(Attendance.getNames());
        this.jTextField2login.setText(Attendance.getIn());
        this.jTextField3logout.setText(Attendance.getOut());
        this.selectedTaskId = Attendance.getAttendanceId();
        this.jTextField4status.setText(Attendance.getStatus());
        this.jTextField5date.setText(Attendance.getDate());

        this.jLabel4.setVisible(true);
        this.jLabel5.setVisible(true);
        this.jTextField5date.setVisible(true);
        this.jTextField4status.setVisible(true);

        this.jButton2delete.setEnabled(true);
        this.saveMode = "UPDATE";
        System.out.println("SaveMode:" + saveMode);
    }

    private void addTask() {
        String desc = this.jTextField1names.getText();
        String in = this.jTextField2login.getText();
        String out = this.jTextField3logout.getText();
        String status = this.jTextField4status.getText();
        boolean success = false;
        if (this.saveMode.equalsIgnoreCase("ADD")) {
            if (desc.trim().isEmpty() || in.trim().isEmpty() || out.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "All Fields are required", "Add Attendance", 0);
                return;
            }
            controller.handleAddTask(desc, in, out);
            success = true;
            JOptionPane.showMessageDialog(this, "Attendance Successfully added", "Add Attendance", 1);
        } else if (this.saveMode.equalsIgnoreCase("UPDATE")) {
            boolean res = controller.handleUpdateTask(this.selectedTaskId, desc, in, out, status);
            if (res) {
                JOptionPane.showMessageDialog(this, "Attendance Successfully Updated", "Update Attendance", 1);
                success = true;
            } else {
                JOptionPane.showMessageDialog(this, "An error occured while updating Attendance", "Update Attendance", 0);
            }
        }
        if (success) {
            this.jTable2listoftasks.clearSelection();
            setUpDefaultDisplay();
            this.selectedTaskId = null;
        }
    }

    private void deleteTask() {
        if (this.selectedTaskId != null) {
            int confirmDeletion = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to delete this Attendance? This cannot be undone.",
                    "Confirm Attendance Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
            if (confirmDeletion == JOptionPane.YES_OPTION) {
                boolean success = controller.handleDeleteTask(this.selectedTaskId);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Attendance Successfully Deleted", "Attendance Deletion", 1);
                    this.jTable2listoftasks.clearSelection();
                } else {
                    JOptionPane.showMessageDialog(this, "An error occured while deleting the Attendance", "Attendance Deletion", 0);
                }
            } else {
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLabel1 = new javax.swing.JLabel();
        jTextField1names = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2login = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField3logout = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField4status = new javax.swing.JTextField();
        jButton1save = new javax.swing.JButton();
        jButton2delete = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextField5date = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButtonRefresh = new javax.swing.JButton();
        jCheckBoxSearch = new javax.swing.JCheckBox();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2listoftasks = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jRadioButtonGoBackHome = new javax.swing.JRadioButtonMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jRadioButtonMenuItemsave = new javax.swing.JRadioButtonMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemdelete = new javax.swing.JRadioButtonMenuItem();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemrefresh = new javax.swing.JRadioButtonMenuItem();
        jSeparator8 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemExit = new javax.swing.JRadioButtonMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jRadioButtonMenuItemSortName = new javax.swing.JRadioButtonMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemOut = new javax.swing.JRadioButtonMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemID = new javax.swing.JRadioButtonMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemDate = new javax.swing.JRadioButtonMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemIn = new javax.swing.JRadioButtonMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        jRadioButtonMenuItemProgram = new javax.swing.JRadioButtonMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ATTENDANCE", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24))); // NOI18N

        jLayeredPane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("NAMES");
        jLayeredPane1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        jTextField1names.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1namesActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jTextField1names, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 28, 160, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("LOG IN");
        jLayeredPane1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 64, -1, -1));

        jTextField2login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2loginActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jTextField2login, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 86, 160, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("LOG OUT");
        jLayeredPane1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 122, -1, -1));

        jTextField3logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3logoutActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jTextField3logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 144, 160, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("PROGRAM");
        jLayeredPane1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 180, -1, -1));

        jTextField4status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4statusActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jTextField4status, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 202, 160, 30));

        jButton1save.setBackground(new java.awt.Color(255, 255, 255));
        jButton1save.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ui/save.png"))); // NOI18N
        jButton1save.setText("SAVE");
        jButton1save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1saveActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jButton1save, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 150, -1));

        jButton2delete.setBackground(new java.awt.Color(255, 255, 255));
        jButton2delete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ui/delete.png"))); // NOI18N
        jButton2delete.setText("DELETE");
        jButton2delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2deleteActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jButton2delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 150, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("DATE");
        jLayeredPane1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 238, -1, -1));

        jTextField5date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5dateActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jTextField5date, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 260, 160, 30));
        jLayeredPane1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 618, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ui/tulipppp.png"))); // NOI18N
        jLayeredPane1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 388, -1, 230));
        jLayeredPane1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, -1, -1));

        jButtonRefresh.setBackground(new java.awt.Color(255, 255, 255));
        jButtonRefresh.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButtonRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ui/refreshs.png"))); // NOI18N
        jButtonRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRefreshActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jButtonRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 20, 20));

        jCheckBoxSearch.setText("Search Mode");
        jCheckBoxSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxSearchActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jCheckBoxSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, -1, -1));

        jTable2listoftasks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable2listoftasks);

        javax.swing.GroupLayout jLayeredPane2Layout = new javax.swing.GroupLayout(jLayeredPane2);
        jLayeredPane2.setLayout(jLayeredPane2Layout);
        jLayeredPane2Layout.setHorizontalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jLayeredPane2Layout.setVerticalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jLayeredPane2.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLayeredPane2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLayeredPane1)
                    .addComponent(jLayeredPane2))
                .addContainerGap())
        );

        jMenu4.setText("Home");

        jRadioButtonGoBackHome.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0));
        jRadioButtonGoBackHome.setSelected(true);
        jRadioButtonGoBackHome.setText("Go Back");
        jRadioButtonGoBackHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonGoBackHomeActionPerformed(evt);
            }
        });
        jMenu4.add(jRadioButtonGoBackHome);

        jMenuBar1.add(jMenu4);

        jMenu1.setText("File");

        jRadioButtonMenuItemsave.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK));
        jRadioButtonMenuItemsave.setSelected(true);
        jRadioButtonMenuItemsave.setText("save");
        jRadioButtonMenuItemsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemsaveActionPerformed(evt);
            }
        });
        jMenu1.add(jRadioButtonMenuItemsave);
        jMenu1.add(jSeparator6);

        jRadioButtonMenuItemdelete.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.ALT_MASK));
        jRadioButtonMenuItemdelete.setSelected(true);
        jRadioButtonMenuItemdelete.setText("delete");
        jRadioButtonMenuItemdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemdeleteActionPerformed(evt);
            }
        });
        jMenu1.add(jRadioButtonMenuItemdelete);
        jMenu1.add(jSeparator7);

        jRadioButtonMenuItemrefresh.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_MASK));
        jRadioButtonMenuItemrefresh.setSelected(true);
        jRadioButtonMenuItemrefresh.setText("refresh");
        jRadioButtonMenuItemrefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemrefreshActionPerformed(evt);
            }
        });
        jMenu1.add(jRadioButtonMenuItemrefresh);
        jMenu1.add(jSeparator8);

        jRadioButtonMenuItemExit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.ALT_MASK));
        jRadioButtonMenuItemExit.setSelected(true);
        jRadioButtonMenuItemExit.setText("Exit");
        jRadioButtonMenuItemExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemExitActionPerformed(evt);
            }
        });
        jMenu1.add(jRadioButtonMenuItemExit);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Filter");

        jRadioButtonMenuItemSortName.setSelected(true);
        jRadioButtonMenuItemSortName.setText("Sort Name");
        jRadioButtonMenuItemSortName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemSortNameActionPerformed(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItemSortName);
        jMenu3.add(jSeparator2);

        jRadioButtonMenuItemOut.setSelected(true);
        jRadioButtonMenuItemOut.setText("Sort Out");
        jRadioButtonMenuItemOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemOutActionPerformed(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItemOut);
        jMenu3.add(jSeparator1);

        jRadioButtonMenuItemID.setSelected(true);
        jRadioButtonMenuItemID.setText("Sort ID");
        jRadioButtonMenuItemID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemIDActionPerformed(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItemID);
        jMenu3.add(jSeparator3);

        jRadioButtonMenuItemDate.setSelected(true);
        jRadioButtonMenuItemDate.setText("Sort Date");
        jRadioButtonMenuItemDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemDateActionPerformed(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItemDate);
        jMenu3.add(jSeparator4);

        jRadioButtonMenuItemIn.setSelected(true);
        jRadioButtonMenuItemIn.setText("Sort In");
        jRadioButtonMenuItemIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemInActionPerformed(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItemIn);
        jMenu3.add(jSeparator5);

        jRadioButtonMenuItemProgram.setText("Sort Program");
        jRadioButtonMenuItemProgram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemProgramActionPerformed(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItemProgram);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1namesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1namesActionPerformed
    }//GEN-LAST:event_jTextField1namesActionPerformed

    private void jTextField2loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2loginActionPerformed
    }//GEN-LAST:event_jTextField2loginActionPerformed

    private void jTextField3logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3logoutActionPerformed
    }//GEN-LAST:event_jTextField3logoutActionPerformed

    private void jTextField4statusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4statusActionPerformed
    }//GEN-LAST:event_jTextField4statusActionPerformed

    private void jTextField5dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5dateActionPerformed
    }//GEN-LAST:event_jTextField5dateActionPerformed
//taskList.sort(Comparator.comparing(taskList -> taskList.getName(), String.CASE_INSENSITIVE_ORDER))
    private void jButton1saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1saveActionPerformed
        System.out.println("Button Clicked");
        addTask();
    }//GEN-LAST:event_jButton1saveActionPerformed

    private void jButton2deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2deleteActionPerformed
        System.out.println("Delete is clicked!");
        deleteTask();
    }//GEN-LAST:event_jButton2deleteActionPerformed

    private void jButtonRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRefreshActionPerformed
        refreshThat();
    }//GEN-LAST:event_jButtonRefreshActionPerformed

    private void jRadioButtonMenuItemsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemsaveActionPerformed
        System.out.println("Button Clicked");
        addTask();
    }//GEN-LAST:event_jRadioButtonMenuItemsaveActionPerformed

    private void jRadioButtonMenuItemdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemdeleteActionPerformed
        System.out.println("Delete is clicked!");
        deleteTask();
    }//GEN-LAST:event_jRadioButtonMenuItemdeleteActionPerformed

    private void jRadioButtonMenuItemrefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemrefreshActionPerformed
        refreshThat();
    }//GEN-LAST:event_jRadioButtonMenuItemrefreshActionPerformed

    private void jRadioButtonMenuItemSortNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemSortNameActionPerformed
        System.out.println("Button Clicked");
        sortedName();
    }//GEN-LAST:event_jRadioButtonMenuItemSortNameActionPerformed

    private void jRadioButtonMenuItemDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemDateActionPerformed
        System.out.println("Button Clicked");
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        Attendances.sort(Comparator.comparing(attendance -> attendance.getDate(), String.CASE_INSENSITIVE_ORDER));
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }
    }//GEN-LAST:event_jRadioButtonMenuItemDateActionPerformed

    private void jRadioButtonMenuItemIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemIDActionPerformed
        System.out.println("Button Clicked");
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        Attendances.sort(Comparator.comparing(attendance -> attendance.getAttendanceId(), String.CASE_INSENSITIVE_ORDER));
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }
    }//GEN-LAST:event_jRadioButtonMenuItemIDActionPerformed

    private void jRadioButtonMenuItemInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemInActionPerformed
        System.out.println("Button Clicked");
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        Attendances.sort(Comparator.comparing(attendance -> attendance.getIn(), String.CASE_INSENSITIVE_ORDER));
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }
    }//GEN-LAST:event_jRadioButtonMenuItemInActionPerformed

    private void jRadioButtonMenuItemOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemOutActionPerformed
        System.out.println("Button Clicked");
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        Attendances.sort(Comparator.comparing(attendance -> attendance.getOut(), String.CASE_INSENSITIVE_ORDER));
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }
    }//GEN-LAST:event_jRadioButtonMenuItemOutActionPerformed

    private void jRadioButtonMenuItemProgramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemProgramActionPerformed
        System.out.println("Button Clicked");
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        Attendances.sort(Comparator.comparing(attendance -> attendance.getStatus(), String.CASE_INSENSITIVE_ORDER));
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }
    }//GEN-LAST:event_jRadioButtonMenuItemProgramActionPerformed

    private void refreshThat() {
        System.out.println("Refresh is clicked!");
        this.jCheckBoxSearch.setSelected(false);
        setUpDefaultDisplay();
        refreshAttendanceList();
        jTextField1names.setText("");
        jTextField2login.setText("");
        jTextField3logout.setText("");
        jTextField4status.setText("");
        jTextField5date.setText("");

        this.jLabel4.setVisible(false);
        this.jLabel5.setVisible(false);
        this.jTextField5date.setVisible(false);
        this.jTextField4status.setVisible(false);
    }

    private FocusListener searchFocusListener = new FocusListener() {
        public void focusGained(FocusEvent e) {
            search();
        }

        public void focusLost(FocusEvent e) {
            // Do nothing
        }
    };
    private void jCheckBoxSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxSearchActionPerformed

        if (jCheckBoxSearch.isSelected()) {
            // Enable text fields for search
            jTextField1names.setEnabled(true);
            jTextField2login.setEnabled(true);
            jTextField3logout.setEnabled(true);
            jTextField4status.setEnabled(true);
            jTextField5date.setEnabled(true);

            this.jLabel4.setVisible(true);
            this.jLabel5.setVisible(true);
            this.jTextField5date.setVisible(true);
            this.jTextField4status.setVisible(true);

            jTextField1names.addFocusListener(searchFocusListener);
            jTextField2login.addFocusListener(searchFocusListener);
            jTextField3logout.addFocusListener(searchFocusListener);
            jTextField4status.addFocusListener(searchFocusListener);
            jTextField5date.addFocusListener(searchFocusListener);

            // Add key listeners to text fields
            jTextField1names.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    if (jCheckBoxSearch.isSelected()) {
                        search();
                    }
                }
            });
            jTextField2login.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    if (jCheckBoxSearch.isSelected()) {
                        search();
                    }
                }
            });
            jTextField3logout.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    if (jCheckBoxSearch.isSelected()) {
                        search();
                    }
                }
            });
            jTextField4status.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    if (jCheckBoxSearch.isSelected()) {
                        search();
                    }
                }
            });
            jTextField5date.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    if (jCheckBoxSearch.isSelected()) {
                        search();
                    }
                }
            });

            // Call search() if text fields are not empty
            if (!jTextField1names.getText().isEmpty() || !jTextField2login.getText().isEmpty()
                    || !jTextField3logout.getText().isEmpty() || !jTextField4status.getText().isEmpty()
                    || !jTextField5date.getText().isEmpty()) {
                search();
//            refreshAttendanceList();
            }

        } else {
            // Disable search functionality
            this.jLabel4.setVisible(false);
            this.jLabel5.setVisible(false);
            this.jTextField5date.setVisible(false);
            this.jTextField4status.setVisible(false);

            jTextField1names.removeFocusListener(searchFocusListener);
            jTextField2login.removeFocusListener(searchFocusListener);
            jTextField3logout.removeFocusListener(searchFocusListener);
            jTextField4status.removeFocusListener(searchFocusListener);
            jTextField5date.removeFocusListener(searchFocusListener);

        refreshAttendanceList();
        }

    }//GEN-LAST:event_jCheckBoxSearchActionPerformed

    private void jRadioButtonMenuItemExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jRadioButtonMenuItemExitActionPerformed

    private void jRadioButtonGoBackHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonGoBackHomeActionPerformed
        openHome();
    }//GEN-LAST:event_jRadioButtonGoBackHomeActionPerformed

    public void openHome(){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
        dispose();
    }
    
    public void sortedName() {
        String savedSelectedId = this.selectedTaskId;
        System.out.println("Selected Attendance id:" + savedSelectedId);

        List<Attendance> Attendances = controller.getAllTask();
        Attendances.sort(Comparator.comparing(attendance -> attendance.getNames(), String.CASE_INSENSITIVE_ORDER));
        for (Attendance Attendance : Attendances) {
            System.out.println(Attendance);
        }
        this.tableModel.setTasks(Attendances);

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getAttendanceId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTable2listoftasks.convertRowIndexToView(newModelRow);
                jTable2listoftasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaultDisplay();
            }
        }

//        List<Attendance> attendances = controller.getAllTask();
//        attendances.sort(Comparator.comparing(attendance -> attendance.getNames(), String.CASE_INSENSITIVE_ORDER));
//        return attendances;
    }

    private AttendanceController controller;
    private AttendanceTableModel tableModel;
    private String selectedTaskId;
    private String saveMode;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1save;
    private javax.swing.JButton jButton2delete;
    private javax.swing.JButton jButtonRefresh;
    private javax.swing.JCheckBox jCheckBoxSearch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonGoBackHome;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemDate;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemExit;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemID;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemIn;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemOut;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemProgram;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemSortName;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemdelete;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemrefresh;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemsave;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JPopupMenu.Separator jSeparator8;
    private javax.swing.JTable jTable2listoftasks;
    private javax.swing.JTextField jTextField1names;
    private javax.swing.JTextField jTextField2login;
    private javax.swing.JTextField jTextField3logout;
    private javax.swing.JTextField jTextField4status;
    private javax.swing.JTextField jTextField5date;
    // End of variables declaration//GEN-END:variables

    private boolean exactMatch = false;

    private void search() {
        String name = jTextField1names.getText().trim().toLowerCase();
        String in = jTextField2login.getText().trim();
        String out = jTextField3logout.getText().trim().toLowerCase();
        String status = jTextField4status.getText().trim().toLowerCase();
        String date = jTextField5date.getText().trim().toLowerCase();

        List<Attendance> attendances = controller.getAllTask();
        List<Attendance> filteredAttendances = new ArrayList<>();

        for (Attendance attendance : attendances) {
            boolean match = true;

            if (!name.isEmpty()) {
                if (exactMatch && !attendance.getNames().toLowerCase().equals(name)) {
                    match = false;
                } else if (!exactMatch && !attendance.getNames().toLowerCase().contains(name)) {
                    match = false;
                }
            }

            if (!in.isEmpty() && !attendance.getIn().equals(in)) {
                match = false;
            }

            if (!out.isEmpty() && !attendance.getOut().toLowerCase().equals(out)) {
                match = false;
            }

            if (!status.isEmpty()) {
                if (exactMatch && !attendance.getStatus().toLowerCase().equals(status)) {
                    match = false;
                } else if (!exactMatch && !attendance.getStatus().toLowerCase().contains(status)) {
                    match = false;
                }
            }

            if (!date.isEmpty()) {
                if (exactMatch && !attendance.getDate().toLowerCase().equals(date)) {
                    match = false;
                } else if (!exactMatch && !attendance.getDate().toLowerCase().contains(date)) {
                    match = false;
                }
            }

            if (match) {
                filteredAttendances.add(attendance);
            }
        }

        // Update the table model with the filtered attendances
        tableModel.setTasks(filteredAttendances);
    }

}
